let os = require("os");
console.log("os.arch() says ",os.arch());
console.log("os.totalmem() says ",os.totalmem());
console.log("os.freemem() says ",os.freemem());
console.log("os.cpus().length says ",os.cpus().length);
console.log("os.cpus()[0] says ",os.cpus()[0]);
console.log("os.userInfo().username says ",os.userInfo().username);