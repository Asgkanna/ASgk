let fs = require("fs");
fs.writeFile("data.txt","Welcome to your life, there's no turning back","utf-8",function(error){
    if(error){ console.log("Error ", error) }
    else{ console.log("File is created") }
})