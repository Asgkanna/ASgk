let obj = require("./one.js");

console.log(obj.hero.title);
console.log(obj.user);