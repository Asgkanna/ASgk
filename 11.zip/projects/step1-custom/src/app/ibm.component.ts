import { Component, NgModule  } from "@angular/core";

@Component({
    selector : 'app-ibm',
    template :' <h1>{{ title }}</h1> '
})
export class IBMComp{
    title = "Hello From IBM India ";
}