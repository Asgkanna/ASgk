import {  NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { IBMComp } from "./ibm.component";
import { IBMDirective } from "./ibm.directive";
import { RevPipe } from "./rev.pipes";

@NgModule({
    declarations : [ IBMComp,IBMDirective , RevPipe ,],
    imports : [ FormsModule],
    providers : [],
    bootstrap : [],
    exports : [IBMComp,IBMDirective, RevPipe ],
})
export class IBMModule{}
