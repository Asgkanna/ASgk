import { Directive, ElementRef, Input, OnChanges } from "@angular/core";
 
/*
tag directive : 'ibm'
attribute directive : '[ibm]'
class directive : '.ibm'
*/
 
@Directive({
    selector : 'ibm'
})
export class IBMDirective{
    // @Input() ibm = 'silver';
    @Input() ibmcol = 'silver';
    @Input() ibmweight:any = 16;
    constructor(private elRef:ElementRef){}
    ngOnInit(){
        let vals = this.elRef.nativeElement.innerText;
        this.elRef.nativeElement.style.padding = "10px";
        this.elRef.nativeElement.style.margin = "5px";
        this.elRef.nativeElement.style.fontSize = this.ibmweight+"px";
        this.elRef.nativeElement.innerText= vals+" "+this.ibmcol;
        this.elRef.nativeElement.addEventListener("click", ()=>{
            this.elRef.nativeElement.style.backgroundColor = this.ibmcol;
        });
    }
   
}
 
/*
attribute
+++++++++
*ngIf
*ngFor
ngSwitch
ngStyle
ngCass
ngNonBindable
[(ngModel)] from formsModule
--------------
tag
+++
router-outlet from routerModule
ng-content
ng-template
 
*/