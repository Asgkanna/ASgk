import { Pipe } from "@angular/core";

@Pipe({
    name : "rev"
})
export class RevPipe{
    transform(arg:string){
        return arg.split("").reverse().join("");
    }
}