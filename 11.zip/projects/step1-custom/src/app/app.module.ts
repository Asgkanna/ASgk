import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { RevPipe } from './rev.pipes';
import { IBMDirective } from './ibm.directive';
import { IBMModule } from './ibm.module';

@NgModule({
  declarations: [ AppComponent, ],
  imports: [ BrowserModule , IBMModule ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }