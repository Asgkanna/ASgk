import { Component } from '@angular/core';
 
@Component({
  selector: 'app-root',
  template: `
   <h2>{{ title | rev }}</h2>
   <h2>{{ 'welcome to your life' | rev }}</h2>
   <h2>{{ 'my name is vijay' | rev }}</h2>
   <h2>{{ 'hello from IBM' | rev }}</h2>
   <!-- <ibm>Hello There</ibm> -->
   <!-- <p ibm >Welcome to your life</p> -->
  <!--  <p class="ibm" >Welcome to your life, let's take a break</p> -->
 <!--  <div ibm="orange">your fav color is : </div>
  <div [ibm]="'orange'">your fav color is : </div>
  <div [ibm]="'green'">your fav color is : </div>
  <div [ibm]="'silver'">your fav color is : </div>
  <div [ibm]="'blue'">your fav color is : </div>
  <div [ibm]="'maroon'">your fav color is : </div> -->
 
  <ibm ibmweight="16" ibmcol="orange"> your fav color is : </ibm>
  <ibm ibmweight="24" [ibmcol]="'blue'"> your fav color is : </ibm>
  
  `,
  styles: [`
    ibm{
      display : block;
    }
  `]
})
export class AppComponent {
  title = 'step1-custom';
}