import { AppComponent } from "./app.component";
 
describe("",()=>{
    let app:AppComponent = new AppComponent();
    beforeAll(()=>{
        console.log("beforeAll was called ");
    })
    beforeEach(()=>{
        console.log("beforeEach was called ")
    })
    it("should check the app's title to be defined",()=>{
        // return true;
        // expect(app.title).toBeUndefined();
        expect(app.title).toBeDefined();
    })
    it("shuld check the app's title to be Batman",()=>{
        expect(app.title).toBe('Batman');
    })
    it("shuld check the power to be 10",()=>{
      expect(app.power).toBe(10);
    })
    afterEach(()=>{
        console.log("afterEach was called ")
    })
    afterAll(()=>{
        console.log("afterAll was called ")
    })
})