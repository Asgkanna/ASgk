import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  template: `
    <h2>Child Component</h2>
    <hr>
    <ng-content select="button"></ng-content>
    <ng-content select="ul"></ng-content>
    <ng-content select=".box"></ng-content>
    <ng-content></ng-content>
    <hr>
    <h3> Chils Power is : {{ childPower * 10}}</h3>
    <button (click)="createVersionEvent()">Make Version Event Happen</button>
  `,
  styles: [
  ]
})
export class ChildComponent {
  @Input() childPower:number = 0;
  @Output() version:EventEmitter<any> = new EventEmitter();
  createVersionEvent(){
    this.version.emit();
  }
  }