import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <h1>Communication in Angular</h1>
    <input [value]="power" #rng type="range" 
    (input)="increasePower(rng.value)">
    <h3>Power is {{ power }}</h3>
    <app-child [childPower]="power" (version)="versionHandler()" >
      <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Libero similique ut vitae voluptas ratione qui, enim accusantium beatae, sint tenetur in laborum repudiandae distinctio officia ea ipsa animi sed provident.
      </p>
      <p class="box">
        i am box
        <br>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Et aliquam impedit animi perferendis illum magnam amet. Quae eius assumenda necessitatibus qui animi nam ducimus sequi cupiditate. Cumque reprehenderit obcaecati at.
      </p>
      <ul>
        <li>List Item 1</li>
        <li>List Item 2</li>
        <li>List Item 3</li>
        <li>List Item 4</li>
        <li>List Item 5</li>
      </ul>
      <button>Click Button 1</button>
      <button>Click Button 2</button>
    </app-child>
  `,
  styles: []
})
export class AppComponent {
  title = 'step1-communication';
  power:any = 0;
  increasePower(val:any){
    this.power = Number(val);
  }
  versionHandler(){
    alert("version event happend");
  }
}