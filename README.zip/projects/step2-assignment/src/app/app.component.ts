import { Component } from '@angular/core';
 
@Component({
  selector: 'app-root',
  template: `
  <h1>Main App Component</h1>
  <input #nnum type="number">
  <button (click)="increasePower(nnum.value)">Set Power</button>
  <button (click)="show = !show">Show / Hide</button>
  <hr>
  <app-child [childPower]="power" *ngIf="show"></app-child>
  `,
  styles: []
})
export class AppComponent {
  title = 'step3-lifecycle';
  show = true;
  power:any = 0;
 
  increasePower(val:any){
    this.power = Number(val);
  }
}