import { Component, Input } from "@angular/core";
import { HeroService } from "./hero.services";

@Component({
    selector : 'app-grid',
    template : `
    <h3>App Version {{ appVersion  }}</h3>
    <input #ti type="number">
    <button (click)="setAppVersion(ti.value)">Set Version</button>
    <table class="table  table-striped table-hover table-sm">
    <thead class="table-dark">
      <tr>
        <th>Sl #</th>
        <th>Title</th>
        <th>Full Name</th>
        <th>Poster</th>
        <th>City</th>
        <th>Ticket Price</th>
        <th>Release Date</th>
        <th>Movies List</th>
      </tr>
    </thead>
    <tbody>
      <tr *ngFor="let hero of datalist">
        <td>{{ hero.sl }}</td>
        <td>{{ hero.title | uppercase | lowercase | titlecase }}</td>
        <td>{{ hero.firstname+" "+hero.lastname }}</td>
        <td>
          <img width="60" [src]="hero.poster" [alt]="hero.title">
        </td>
        <td>{{ hero.city | slice : 0:1 }} | {{ hero.city }} </td>
        <td>{{ hero.ticketprice | currency : 'INR' : 'symbol' : '4.2-3' }}</td>
        <td>{{ hero.releasedate | date : 'dd / MMM / yyyy' }}</td>
        <td>{{ hero.movieslist.length }}</td>
      </tr>
    </tbody>
   </table>
    
    `
})
export class GridComp{
  @Input() datalist:any = [];
  appVersion = 0;
  constructor(private hs:HeroService){
    this.datalist = this.hs.getData();
    this.appVersion = this.hs.getVersion();
  }
  setAppVersion(num:any){
    this.hs.setVersion(Number(num));
    this.appVersion = this.hs.getVersion();
  }
}

/* export class GridComp{
    @Input() datalist:any = [];
    appVersion = 0;
    hs:HeroService = new HeroService();
    constructor(){
      this.datalist = this.hs.getData();
      this.appVersion = this.hs.getVersion();
    }
    setAppVersion(num:any){
      this.hs.setVersion(Number(num));
      this.appVersion = this.hs.getVersion();
    }
} */