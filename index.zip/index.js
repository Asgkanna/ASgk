let express = require("express");
let cors = require("cors");
let mongoose = require("mongoose"); // ORM
 
let config = require("./config.json");
 
let app = express();
app.use(cors());
app.use(express.json());
//================================
let Schema = mongoose.Schema;
let ObjectId = Schema.ObjectId;
let Hero = mongoose.model("Hero",Schema({
    id : ObjectId,
    title : String,
    firstname : String,
    lastname :String,
    city : String
}));
mongoose.connect(config.url)
.then(res=>console.log("DB Connected"))
.catch(error=>console.log("Error ", error));
//================================
 
/* READ
setTimeout(()=>{
    Hero.find().then(res=>console.log(res)).catch(error=>console.log("Error", error));
},4000); 
*/
/* CREATE
setTimeout(()=>{
    let hero = {
        title : "Captain America",
        firstname : "Steve",
        lastname : "Rogers",
        city : "New York"
    }
    let dbhero = new Hero(hero);
    dbhero.save().then(res=> console.log("hero was added to database")).catch(error=>console.log("Error ", error));
},4000); 
*/
/* DELETE
setTimeout(()=>{
    Hero.findByIdAndDelete({_id:"select an id from database"})
    .then(res=>console.log(res.title+" Deleted"))
    .catch(error=>console.log("Error", error));
},4000);  
*/
 
// CRUD : Create Read Update Delete
// READ 
app.get("/data", (req, res)=>{
    // setTimeout(()=>{},2000); 
    Hero.find()
    .then(dbres=>res.json(dbres))
    .catch(error=>console.log("Error", error));
})
// CREATE
app.post("/data", (req, res)=>{
    // console.log(req.body);
    let dbhero = new Hero(req.body);
    dbhero.save()
    .then(dbRes=> res.json({'message':'hero is now saved'}))
    .catch(error=>console.log("Error ", error));
})
 
// EDIT
app.get("/edit/:heroid", (req, res)=>{
  Hero.findById( req.params.heroid )
    .then(dbres => res.json(dbres))
    .catch(error => console.log("Error", error));
})
 
// UPDATE
app.post("/edit/", (req, res)=>{
  Hero.findById( req.body._id )
    .then(dbres => {
    let hero = new Hero(dbres);
        hero.title = req.body.title;
        hero.firstname = req.body.firstname;
        hero.lastname = req.body.lastname;
        hero.city = req.body.city;
        hero.save()
        .then( storeRes => res.json({"message":"hero info updated"}))
        .catch(error => console.log("Error", error))
    })
    .catch(error => console.log("Error", error));
})
 
// DELETE
app.delete("/delete/:heroid", (req, res)=>{
    // Hero.findByIdAndDelete({_id: req.params.heroid })
    Hero.findByIdAndDelete(req.params.heroid)
    .then(dbRes=> res.json({'deleted':dbRes.title}))
    .catch(error=>console.log("Error", error));
})
 
app.listen(5050,"localhost");
console.log("server is now live on localhost:5050")