import { Component } from "react";

class ChildComponent extends Component{
  render(){
    return <div>
        <h2>Child Component</h2>
        <h3>Title : { this.props.title }</h3>
        <h3>Version  : { this.props.version }</h3>
    </div>
  }


}

export { ChildComponent }