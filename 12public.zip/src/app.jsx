import React,{ Component } from "react";
import{ ChildComponent } from "./child";


class App extends Component{
    state = {
    ver : 101
    }
    render(){
        return <div className="container">
           <h1>Props and State</h1>
           <button onClick={ this.clickHandler.bind(this) }>CLick To change version</button>
           <hr />
           <ChildComponent version={this.state.ver} title={'First App Title'}/>
           <hr />
           <ChildComponent version={this.state.ver} title={'Second App Title'}/>
           <hr />
           <ChildComponent version={this.state.ver} title={'Third App Title'}/>
        </div>
    }
    clickHandler(){
        this.setState({
            ver : Math.round( Math.random() * 1000)
        })
       
    }
}

export { App } 