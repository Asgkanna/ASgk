let express = require("express");
let data = require("./data/data.json");
let app = express();
app.get("/", function(req, res){
    //res.sendfile(__)

    res.send("data");
});
app.listen(5050, "localhost")
console.log("Server is now live on localhost:5050");