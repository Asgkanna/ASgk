let EventEmitter = require("events").EventEmitter;

let ee = new EventEmitter();
var count = 0;

function ibmEventHandler(){
    console.log("IBM Event Happened");
}
ee.addListener("ibmEvent", ibmEventHandler);
var ci = setInterval(function(){
    console.log("interval happened");
    if(count < 5){
        ee.emit("ibmEvent");
        count++;
    }else{
        clearInterval(ci);
    }
},2000)