let http = require("http");
let fs = require("fs");

let server = http.createServer(function(req, res){
    /*
    res.write("hello from my server");
    res.end();
    */
/*
res.write(
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IBM India</title>
</head>
<body>
    <h1>IBM | INDIA | BANGALORE</h1>
    <P>
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Velit quis excepturi fugit saepe mollitia. Necessitatibus eos animi cumque amet repellendus totam fugiat dolorum, perspiciatis ullam veniam molestiae. Soluta, deleniti repellendus.
    </P>
    <P>
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Velit quis excepturi fugit saepe mollitia. Necessitatibus eos animi cumque amet repellendus totam fugiat dolorum, perspiciatis ullam veniam molestiae. Soluta, deleniti repellendus.
    </P>
    <P>
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Velit quis excepturi fugit saepe mollitia. Necessitatibus eos animi cumque amet repellendus totam fugiat dolorum, perspiciatis ullam veniam molestiae. Soluta, deleniti repellendus.
    </P>
    <P>
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Velit quis excepturi fugit saepe mollitia. Necessitatibus eos animi cumque amet repellendus totam fugiat dolorum, perspiciatis ullam veniam molestiae. Soluta, deleniti repellendus.
    </P>
</body>
</html>
);
*/

res.write( fs.readFileSync("temp.html","utf-8").replace("{ compname}", "My Company"));
res.end();
});

server.listen(5050, "localhost", function(error){
    if(error){console.log("Error", error) }
    else{ console.log("server is now live on localhost:5050")}
})