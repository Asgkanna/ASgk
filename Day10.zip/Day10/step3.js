let fetch = require("fetch");
let fs = require("fs");

fetch.fetchUrl("https://www.ibm.com/in-en", function(error, meta,res){
    if(error){
        console.log("Error ", error);
    }else{
       // console.log(res.toString());
       fs.writeFile("temp.html", res,"utf-8", function(error){
        if(error){ console.log("Error ", error)}
        else{
            console.log("File created")
        }
       })
    }
})