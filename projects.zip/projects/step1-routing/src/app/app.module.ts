import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { HomeComponent } from './home.component';
import { BatmanComponent } from './batman.component';
import { SupermanComponent } from './superman.component';
import { AquamanComponent } from './aquaman.component';
import { NotfoundComponent } from './notfound.component';
import { RouterModule } from '@angular/router';
import { HeroService } from './herolist.service';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    BatmanComponent,
    SupermanComponent,
    AquamanComponent,
    NotfoundComponent
  ],
  imports: [ BrowserModule, FormsModule, RouterModule.forRoot([
    { path : '',  component : HomeComponent },
    { path : 'batman',  component : BatmanComponent },
    { path : 'superman/:pow',  component : SupermanComponent },
    { path : 'superman',  component : SupermanComponent },
    { path : 'aquaman',  component : AquamanComponent },
    { path : 'flash', redirectTo:"batman", pathMatch:'full'},
    { path : '**',  component : NotfoundComponent },
  ]) ],
  providers: [HeroService],
  bootstrap: [AppComponent]
})
export class AppModule { }