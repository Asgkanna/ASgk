import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-aquaman',
  template: `
    <h2>Aquaman works!</h2>
    <button (click)="goToBatman()">Navigate to Batman</button>
    <button (click)="goToSuperman()">Navigate to Superman with parameters</button>
  `,
  styles: [
  ]
})
export class AquamanComponent {

  constructor(private rtr:Router) {}
  gotoBAtman(){
    this.rtr.navigate(['Batman']);
  }
goToSuperman(){
  this.rtr.navigate(['superman',50])
}
}
