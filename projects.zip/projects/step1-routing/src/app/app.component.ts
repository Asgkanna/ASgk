import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <h1>Routing 101</h1>

    <input [(ngModel)]="power" type="range">{{ power }}
    <ul>
    <li> <a routerLinkActive="selected" [routerLinkActiveOptions]="{exact : true }" [routerLink]="['/']">Home</a> </li>
    <li> <a routerLinkActive="selected" [routerLink]="['batman']">Batman</a> </li>
    <li> <a routerLinkActive="selected" [routerLinkActiveOptions]="{exact : true }" [routerLink]="['superman']">superman</a> </li>
    <li> <a routerLinkActive="selected" [routerLink]="['superman',power]">Superman with paras</a> </li>
    <li> <a routerLinkActive="selected" [routerLink]="['aquaman']">Aquaman</a> </li>
    <li> <a routerLinkActive="selected" [routerLink]="['flash']">Flash</a> </li>
    <li> <a routerLinkActive="selected" [routerLink]="['hulk']">Hulk</a> </li>
   </ul>
    <router-outlet></router-outlet>
  `,
  styles: [`
  .selected{
    background-color : crimson;
    display : inline-block;
    width : 100px;
    padding : 10px;
    margin-top : 5px;
    text-align : center;
    color : white;
    text-decoration : none;
  }
  `]
})
export class AppComponent {
  power = 0;
  title = 'step1-routing';
}