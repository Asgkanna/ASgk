import { Component, OnInit } from '@angular/core';
import { HeroService } from './herolist.service';

@Component({
  selector: 'app-batman',
  template: `
    <h2>batman works!</h2>
    <input [(ngModel)]="power" type="range">{{ power }}
    <li> <a routerLinkActive="selected"[routerLink]="['/superman',power]">Superman with Params</a></li>
    <ol>
      <li *ngFor="let movie of compMovies">{{ movie }}</li>
    </ol>
  `,
  styles: [
  ]
})
export class BatmanComponent implements OnInit {
  compMovies:any =[];
power = 0;
  constructor(private hs:HeroService) { }
  
  reload(){
    this.compMovies = this.hs.getMovie();
  }
  ngOnInit(): void {
    this.reload();
  }

}