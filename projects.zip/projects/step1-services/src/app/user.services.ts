import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
 
@Injectable()
export class UserServices{
    
    localurl = "http://localhost:5050";
    remoteurl = "https://jsonplaceholder.typicode.com/users";
 
    constructor(private http:HttpClient){}
    // READ
    getUsers(){
        return this.http.get(this.localurl+"/data");
    }
    // CREATE
    postUser(nhero:any){
        return this.http.post(this.localurl+"/data", nhero);
    }
    // READ BEFORE EDIT
    editSelectedUser(selectedHero:any){
        return this.http.get(this.localurl+"/edit/"+selectedHero);
    }
    // EDIT
    updateSelectedUser(updateVal:any){
        // return this.http.post(this.localurl+"/edit/"+updateVal.id, updateVal);
        return this.http.post(this.localurl+"/edit", updateVal);
    }
    // DELETE
    deleteUser(hid:any){
        return this.http.delete(this.localurl+"/delete/"+hid);
    }
}