import { Component, EventEmitter, Input, Output } from "@angular/core";
import { UserServices } from "./user.services";
 
@Component({
    selector : 'app-grid',
    template : `
     <h3 *ngIf="gridData.length === 0">Waiting for Heroes</h3>
    <table class="table table-responsive table-hover">
      <thead>
        <tr>
          <th>Sl#</th>
          <th>Title</th>
          <th>First Name</th>
          <th>Last Name</th>
          <th>City</th>
          <th>Edit Hero</th>
          <th>Delete</th>
        </tr>
      </thead>
      <tbody>
        <tr *ngFor="let hero of gridData; index as idx">
          <td>{{ idx + 1 }}</td>
          <td>{{ hero.title }}</td>
          <td>{{ hero.firstname }}</td>
          <td>{{ hero.lastname }}</td>
          <td>{{ hero.city }}</td>
          <td>
            <button (click)="editHero(hero._id)" class="btn btn-warning">Edit</button>
          </td>
          <td>
            <button (click)="deleteHero(hero._id)" class="btn btn-danger">Delete</button>
          </td>
        </tr>
      </tbody>
    </table>
    <p>
        {{ gridData | json }}
    </p>
    `
})
export class GridComp{
    @Input() gridData:any = [];
    @Output() heroDeletedEvent:EventEmitter<any> = new EventEmitter();
    @Output() heroEditEvent:EventEmitter<any> = new EventEmitter();
    constructor(private us:UserServices){}
    editHero(hid:any){
       this.us.editSelectedUser(hid).subscribe( res => {
            this.heroEditEvent.emit(res);
       }) 
    }
    deleteHero(hid:any){
        this.us.deleteUser(hid).subscribe(res=>{
            this.heroDeletedEvent.emit(res);
        })
    }
}