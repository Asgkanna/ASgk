import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    name : 'gen'
})
export class GenPipe implements PipeTransform{
    transform(...args:any){
        if(args[1] === "female"){
            return "miss "+args[0]
        }else{
            return "mr "+args[0]
        }
    }
    }