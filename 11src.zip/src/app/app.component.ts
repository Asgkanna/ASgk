import { Component } from '@angular/core';
 
@Component({
  selector: 'app-root',
  template: `
    <h1>Directives</h1>
   <!--  <label for="terms"> Show Terms and Conditions : 
      <input [checked]="show" id="terms" type="checkbox" (change)="show = !show">
    </label>
    <div [hidden]="!show">
      <h2>Terms & Conditions</h2>
      <hr>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Magni voluptates iste hic incidunt tenetur! Illo harum et doloremque molestiae cumque aliquid necessitatibus soluta tempore magni ea, fugiat veniam exercitationem enim!
        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Rerum, ea dolore dignissimos eaque, consectetur alias, in iste sed temporibus veniam officia amet minima laboriosam! Aperiam tenetur quia corporis alias consequuntur.
     </p>
    </div> -->
    <label for="terms"> Show Terms and Conditions : 
      <input [checked]="show" id="terms" type="checkbox" (change)="show = !show">
    </label>
    <!-- <div *ngIf="show">
      <h2>Terms & Conditions</h2>
      <hr>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Magni voluptates iste hic incidunt tenetur! Illo harum et doloremque molestiae cumque aliquid necessitatibus soluta tempore magni ea, fugiat veniam exercitationem enim!
        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Rerum, ea dolore dignissimos eaque, consectetur alias, in iste sed temporibus veniam officia amet minima laboriosam! Aperiam tenetur quia corporis alias consequuntur.
      </p>
    </div> -->
   <!--  
    <ng-template [ngIf]="show">
      <button>Click Me</button>
      <button>Click Me</button>
    </ng-template> 
   -->
 
    <div *ngIf="show; else hiddenElm">
      <h2>Terms & Conditions</h2>
      <hr>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Magni voluptates iste hic incidunt tenetur! Illo harum et doloremque molestiae cumque aliquid necessitatibus soluta tempore magni ea, fugiat veniam exercitationem enim!
        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Rerum, ea dolore dignissimos eaque, consectetur alias, in iste sed temporibus veniam officia amet minima laboriosam! Aperiam tenetur quia corporis alias consequuntur.
      </p>
    </div>
    <ng-template  #hiddenElm>
      <h2>Terms & Conditions are hidden</h2>
    </ng-template>
 
  <input #rng type="range" [value]="rateing" min="0" max="5" (input)="rateing = rng.value">
  {{ rateing }}
  <div [ngSwitch]="rateing">
    <h2 *ngSwitchCase="1" >Rateing is : *</h2>
    <h2 *ngSwitchCase="2" >Rateing is : **</h2>
    <h2 *ngSwitchCase="3" >Rateing is : ***</h2>
    <h2 *ngSwitchCase="4" >Rateing is : ****</h2>
    <h2 *ngSwitchCase="5" >Rateing is : *****</h2>
    <h2 *ngSwitchDefault >Not Yet Rated</h2>
  </div>
<!--   
  <ol>
    <li>{{ avengers[0] }}</li>
    <li>{{ avengers[1] }}</li>
    <li>{{ avengers[2] }}</li>
    <li>{{ avengers[3] }}</li>
  </ol> 
-->
<input #hero type="text" (change)="avengers.push(hero.value); hero.value=''">
  <div>
    <article [class.oddbox]="od" [class.evenbox]="ev"  *ngFor="let hero of avengers; index as idx; odd as od; even as ev; first as fst; last as lst">
      {{ idx+1 +" "+ hero }}
      <span *ngIf="od">Odd Element</span>
      <span *ngIf="ev">Even Element</span>
      <span *ngIf="fst">First Element</span>
      <span *ngIf="lst">Last Element</span>
    </article>
  </div>
  `,
  styles: [`
    .oddbox{
      background-color : grey
    }
    .evenbox{
      background-color : silver
    }
  `]
})
export class AppComponent {
  title = 'step2-directives';
  show = true;
  rateing:any = 0;
  avengers:any = [];
}
